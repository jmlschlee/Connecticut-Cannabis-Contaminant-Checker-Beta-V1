# Changelog

All notable changes to CannaScope are documented here. Older versions are **preserved** — nothing has been deleted.

## [v5.0.0-beta] — CannaScope Beta V5 (public release)

**Standardized the public-facing version name to *CannaScope Beta V5*.** Internal development builds used "V7" naming; those builds remain in the repository history for transparency.

### Added
- **Testing Date** column throughout every product-level table (parsed from the COA's test/sample date, never the report-generation date; falls back to the registry date only when the COA has none).
- **CT Legal Limit** and **CannaScope Limit** comparison columns, plus **CT % Of Limit** and **Difference From CannaScope**, so every finding shows its full numeric context in one row.
- **Producer Trends** and **Lab Trends** summaries directly under the Executive Summary.
- **High Cannabinoid Content / High THC Content Findings** section (non-infused flower above 35%) — identifies unusually high cannabinoid content for review, not an accusation.
- **Infused & Extract Potency Comparison Reference** — concentrated products shown to compare against normal flower (high potency expected by design).
- **Possible Remediation / Unusually Low Microbial Load Review** with cautious wording safeguards (explicitly *not* proof of remediation).
- Expanded **Executive Summary dashboard**: Top Heavy Metal, Top Microbial, Top High Cannabinoid, Top Producer Patterns, Top Lab Patterns, and Top Possible Remediation findings.
- **Per-measurement severity colors** (RED / ORANGE / YELLOW / GREEN) on the rank number, CT %, and difference.

### Improved
- Clickable COA references on every finding row.
- Live COA row validation (substantive mismatches only; cosmetic differences ignored).
- Validation status system: `PASS` / `PASS WITH WARNINGS` / `DRAFT` / `FAIL`.
- Zero-result verification (unexpected zeros treated as suspected parser errors until checked against raw parsed data).
- Producer / DBA identity resolution validated against data.ct.gov, CT eLicense, the DCP brand registry, and cited public sources, with a source-confidence score.
- Larger typography, centered headers, wider tables, and a findings-first report order; diagnostics moved to the end.

### Preserved
- All earlier beta builds remain in repository history. No older version was removed or overwritten.

---

## Earlier internal builds (preserved for transparency)

- **"V7" report builds** — introduced the validated, findings-first report engine, the contaminant/cannabinoid parsing, COA validation, and the identity resolver. Standardized publicly as Beta V5.
- **CannaScope CT V2** — full-panel COA parsing across all product types, faster parsing, OCR for scanned COAs, severity-sorted report.
- **Connecticut Cannabis Contaminant Checker — Beta V1** — the original contaminant checker.
