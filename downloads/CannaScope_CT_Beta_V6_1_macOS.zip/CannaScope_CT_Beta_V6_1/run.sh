#!/usr/bin/env bash
set -e; cd "$(dirname "$0")"
python3 -m venv .venv 2>/dev/null || true
. .venv/bin/activate
pip install -q -r requirements.txt
python cannascope_ct_v6_1.py "$@"
